package com.rzm.loadsir;

import com.kingja.loadsir.callback.Callback;
import com.rzm.base.R;

public class LottieEmptyCallback extends Callback {

    @Override
    protected int onCreateView() {
        return R.layout.layout_lottie_empty;
    }

}
