package com.rzm.webview;

import android.databinding.DataBindingUtil;
import android.net.Uri;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.rzm.webview.databinding.ActivityWebViewBinding;
import com.rzm.webview.utils.Constants;

public class WebViewActivity extends AppCompatActivity
        implements WebViewFragment.OnFragmentInteractionListener{

    ActivityWebViewBinding viewBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewBinding = DataBindingUtil.setContentView(this,R.layout.activity_web_view);
        viewBinding.title.setText(getIntent().getStringExtra(Constants.TITLE));
        viewBinding.actionBar.setVisibility(getIntent().getBooleanExtra(Constants.IS_SHOW_ACTION_BAR, true)? View.VISIBLE:View.GONE);
        viewBinding.back.setOnClickListener(v -> WebViewActivity.this.finish());

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        Fragment fragment = WebViewFragment.newInstance(getIntent().getStringExtra(Constants.URL), true);
        transaction.replace(R.id.web_view_fragment, fragment).commit();
    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}
